<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

use \App\Ebook;
Route::get('demo',function(){
    $tag_id = 1;
    $attributes = 2;
    $article = Ebook::find($attributes);
    $article->Library()->attach($tag_id);
    
    //$ebook->Library()->updateExistingPivot($tag_id, $attributes);
    //echo $article;
    return $article; 
});


Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
