<?php

namespace App\Http\Controllers;

use App\Ebook;
use App\Hire;
use Illuminate\Http\Request;
use App\User;
use Illuminate\Support\Facades\Validator;
use App\Library;

class UserController extends Controller
{
    // chap nhan update
    private $updateAccept = ['name', 'password', 'email', 'img', 'phone'];

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'max:255',
            'email' => 'email|unique:users|email',
            'password' => 'min:6',
            'phone' => 'regex:/(0)[0-9]{9}/|max:10|min:6',
        ]);

        if ($validator->fails()) {
            return response()->json(['message' => 'error', 'error' => $validator->errors()], 401);
        }

        /** @var User $user */
        $user = $request->user();

        $data = \request($this->updateAccept);
        foreach ($data as $key => $datum) {
            if (empty($datum)) {
                continue;
            }

            if ($key == 'password') {
                $user->setAttribute($key, bcrypt($datum));
            } elseif ($key == 'img') {
                // remove old file
                $oldFile = public_path('/backend/image/user/' . $user->img);
                if (file_exists($oldFile)) {
                    unlink($oldFile);
                }

                // image nhan ve la base64
                // tao file name
                $fileName = str_random(10) . '_' . (new \DateTime())->format('YmdHmi'). '.jpeg';
                    
                file_put_contents(public_path('/backend/image/user/'.$fileName), base64_decode($datum));

                $user->setAttribute($key, $fileName);
            } else {
                $user->setAttribute($key, $datum);
            }
        }
        // không cho user tự update tiền
//        $user->money = $request->money;

        $user->save();

        return response()->json([
            'message' => 'success',
            'user' => $user->toArray()
        ]);
    }

    /**
     * Lay danh sach da thue
     *
     * Chấp nhận type: 0: hết hạn, 1: còn hạn, 2: all, mặc định là 1
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function getRentEbook(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'type' => 'in:0,1,2', // 0: hết hạn, 1: còn hạn, 2: all
        ]);

        if ($validator->fails()) {
            return response()->json(['message' => 'error', 'error' => $validator->errors()], 401);
        }

        $user = $request->user();
        // mặc định là 1: còn hạn
        $type = $request->get('type', Hire::EXPIRY_DATE);

        // tao cau truy van
        $query = Hire::getRentEbookQuery($user, $type);
        $data = $query->get();

        // tao link cho pdf/image
        $returnData = Ebook::getLinkApi($data);

        return response()->json([
            'message' => 'success',
            'data' => $returnData->toArray()
        ]);
    }

    /**
     * Get user info
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function getUserInfo(Request $request)
    {
        $user = $request->user();

        $user = User::getImageLinkApi($user);

        return response()->json([
            'messsage' => 'success',
            'data' => $user->toArray(),
        ]);
    }

    /**
     * @param Request $request
     * @param $book_id Ebook->getId()
     * @param int $bookmark
     */
    public function readEbook(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'ebook_id' => 'required|numeric|exists:ebook,id',
            'bookmark' => 'numeric',
        ]);

        if ($validator->fails()) {
            return response()->json(['message' => 'error', 'error' => $validator->errors()->first()], 401);
        }

        $ebook_id = $request->get('ebook_id');

        $ebook = Ebook::find($ebook_id);
        $isFree = false;
        /** @var User $user */
        $user = $request->user();
        $bookmark = $request->get('bookmark', 1);
        // free dưới 10 page
        if ($ebook->hire_price == 0 || $bookmark <= 10) {
            $isFree = true;
        }
        // check user rented ebook?
        if (!$isFree) {
            $int = Hire::checkRentedBook($user, $ebook_id);
            if ($int == 0) {
                return response()->json(['message' => 'error', 'error' => 'Ebook is not rented!'], 404);
            }
        }

        // get ebook link
        $link = public_path('backend/ebook/'.$ebook->link_content);

        if (!file_exists($link)) {
            return response()->json(['message' => 'error', 'error' => 'File not found at server!'], 404);
        }

        $pdf = new \Smalot\PdfParser\Parser();
        $text  = $pdf->parseFile($link);
        foreach ($text->getPages() as $key => $pageItem) {
            if ($key == 0) {
                continue;
            }

            if ($key == $bookmark) {
                $str = $pageItem->getText();
                // ÀÁÂÃÈÉÊÌÍÒÓÔÕÙÚĂĐĨŨƠàáâãèéìíòóôõùúăđĩũơƯĂẠẢẤẦẨẪẬẮẰẲẴẶẸẺẼỀẾỂưăạảấầẩẫậắằẳẵặẹẻẽềếểỄỆỈỊỌỎỐỒỔỖỘỚỜỞỠỢỤỦỨỪễệỉịọỏốồổỗộớờởỡợụủứừỬỮỰỲỴÝỶỸửữựỳỵỷỹ
                $str = preg_replace(
                    '/[^a-z0-9A-Z\S\t\nÀÁÂÃÈÉÊÌÍÒÓÔÕÙÚĂĐĨŨƠàáâãèéìíòóôõùúăđĩũơƯĂẠẢẤẦẨẪẬẮẰẲẴẶẸẺẼỀẾỂưăạảấầẩẫậắằẳẵặẹẻẽềếểỄỆỈỊỌỎỐỒỔỖỘỚỜỞỠỢỤỦỨỪễệỉịọỏốồổỗộớờởỡợụủứừỬỮỰỲỴÝỶỸửữựỳỵỷỹ]/miu',
                    '',
                    $str
                );

                // bỏ qua trang trắng
                // if (empty($str)) {
                //     $bookmark++;
                //     continue;
                // }

                return response()->json(
                    ['message' => 'success', 'data' => $str],
                    200,
                    ['Content-type'=> 'application/json; charset=utf-8'],
                    JSON_UNESCAPED_UNICODE
                );
            }
        }

        return response()->json(['message' => 'error', 'error' => 'Cannot find that page!'], 404);
    }

    /**
     * Them vao library
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function addLibrary(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'ebook_id' => 'required|numeric|exists:ebook,id',
            'bookmark' => 'numeric',
        ]);

        if ($validator->fails()) {
            return response()->json(['message' => 'error', 'error' => $validator->errors()->first()], 401);
        }

        $user = $request->user();

        $ebook_id = $request->get('ebook_id');

        /** @var Lirary $Library */
        $Library = Library::where('ebook_id', $ebook_id)->where('user_id', $user->id)->first();
        if ($Library) {
            $Library->bookmark = $request->get('bookmark', $Library->bookmark);
        } else {
            $Library = new Library();
            $Library->user_id = $user->id;
            $Library->ebook_id = $ebook_id;
            $Library->bookmark = $request->get('bookmark', 1);
        }
        
        $Library->save();

        return response()->json([
            'message' => 'success',
            'data' => []
        ], 200);
    }

    /**
     * Xoa library
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function removeLibrary(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'ebook_id' => 'required|numeric|exists:ebook,id',
        ]);

        if ($validator->fails()) {
            return response()->json(['message' => 'error', 'error' => $validator->errors()->first()], 401);
        }

        $user = $request->user();
        $ebook_id = $request->get('ebook_id');

        /** @var Lirary $Library */
        $Library = Library::where('ebook_id', $ebook_id)->where('user_id', $user->id)->first();
        if ($Library) {
            $Library->delete();
        }

        return response()->json([
            'message' => 'success',
            'data' => []
        ], 200);
    }

    public function create(Request $request)
    {
        $users = new User();

        $users->name = $request->name;
        $users->password = $password = bcrypt($request->password);
        $users->mail = $request->mail;
        $users->img = $request->img;
        $users->phone = $request->phone;
        //$users->money = $request->money;

        $users->save();
        return response()->json($users);
    }
}
