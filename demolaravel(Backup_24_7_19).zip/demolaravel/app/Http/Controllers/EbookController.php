<?php

namespace App\Http\Controllers;

use App\Hire;
use Illuminate\Http\Request;
use App\Ebook;
use App\Author;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class EbookController extends Controller
{
    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function getList(Request $request)
    {
        $arrView = ['views', 'id', 'hire_price'];
        $validator = Validator::make($request->all(), [
            Ebook::PAGE_NO => 'numeric|min:1',
            Ebook::LIMIT => 'numeric|min:1',
            Ebook::ORDER_BY => Rule::in($arrView),
            'id' => 'numeric|min:1',
            'min_rate' => 'numeric|min:1',
            'max_rate' => 'numeric|min:1',
            'min_pagenum' => 'numeric',
            'max_pagenum' => 'numeric',
            'min_hire_price' => 'numeric',
            'max_hire_price' => 'numeric',
            'min_price' => 'numeric',
            'max_price' => 'numeric',
            'is_new' => 'in:0,1', // 2 chỉ số 0 hoặc 1
            'publisher_id' => 'exists:Publisher,id', // tồn tại trong bảng Publisher, cột id mới vào được
            'name' => 'regex:/^[a-z\ A-ZÀÁÂÃÈÉÊÌÍÒÓÔÕÙÚĂĐĨŨƠàáâãèéêìíòóôõùúăđĩũơƯĂẠẢẤẦẨẪẬẮẰẲẴẶẸẺẼỀỀỂưăạảấầẩẫậắằẳẵặẹẻẽềềểỄỆỈỊỌỎỐỒỔỖỘỚỜỞỠỢỤỦỨỪễệỉịọỏốồổỗộớờởỡợụủứừỬỮỰỲỴÝỶỸửữựỳỵỷỹ]+$/u|max:255',
            'type' => 'in:home,library'
        ]);

        if ($validator->fails()) {
            return response()->json(['message' => 'error', 'error' => $validator->errors()], 401);
        }

        // số trang (đang ở trang số mấy)
        $pageNo = $request->get(Ebook::PAGE_NO, 1);
        // giới hạn item của 1 trang
        $limit = $request->get(Ebook::LIMIT, 10);
        $orderBy = $request->get(Ebook::ORDER_BY, 'id');
        $searchData = \request(Ebook::$searchFields);

        $user = $request->user();
        // hàm build query cho paginate
        $query = Ebook::getQueryByCondition($searchData, $orderBy, $user->id);

        /** @var LengthAwarePaginator $data phân trang */
        $data = $query->paginate($limit, ['*'], 'page', $pageNo);
        $items = $data->getIterator();

        foreach ($items as $key => $value) {
            $tmpEbook = Ebook::find($value->id);
            $tmpAuthor = [];
            $tmpType = [];
            $tmpLanguage = [];
            if ($tmpEbook) {
                foreach ($tmpEbook->authors as $k => $author) {
                    $tmpAuthor[] = $author->name;
                }

                foreach ($tmpEbook->types as $Type) {
                    $tmpType[] = $Type->name;
                }

                foreach ($tmpEbook->Languages as $k => $Language) {
                    $tmpLanguage[] = $Language->name;
                }
            }
            $items[$key]->author = $tmpAuthor;
            $items[$key]->type = $tmpType;
            $items[$key]->language = $tmpLanguage;
        }
        
        // tao link cho pdf/image
        $data->data = Ebook::getLinkApi($items);

        return response()->json([
            'message' => 'success',
            'data' => $data->toArray(),
        ], 200);
    }

    /**
     * Thue sach
     *
     * @param Request $request
     * @return void
     */
    public function rentEbook(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'ebook_id' => 'required|exists:Ebook,id', // tồn tại trong bảng Ebook, cột id mới pass được
            // 'hour_start' => 'date_format:H:i', // 07:00
            // 'date_start' => 'date_format:Y-m-d', // 2019-07-02
            'rent_day' => 'required|numeric|min:1|max:365', // từ 1 tới 365 ngày
        ]);

        if ($validator->fails()) {
            return response()->json(['message' => 'error', 'error' => $validator->errors()], 401);
        }

        $Ebook = Ebook::find($request->ebook_id);
        // tính tiền tổng các ngày
        $date = (new \DateTime())->modify("+ " . $request->rent_day . ' days');
        $now = new \DateTime();
        $user = $request->user();

        // check đủ tiền
        if ($user->money < $Ebook->hire_price) {
            return response()->json(['message' => 'error', 'error' => 'You don\'t have enough money'], 401);
        }

        // tạo hire
        $hire = new Hire();
        $hire->hour_start = $now->format('h:m');
        $hire->date_start = $now->format('Y-m-d');
        $hire->ebook_id = $request->ebook_id;
        $hire->hour_end = $hire->hour_start;
        $hire->date_end = $date->format('Y-m-d');
        $hire->hire_price = $Ebook->hire_price;
        $hire->total_price = $Ebook->hire_price * $request->rent_day;
        $hire->user_id = $user->id;

        // trừ tiền
        $user->money = $user->money - $hire->total_price;
        $user->save();

        // increase view
        $Ebook->views += 1;
        $Ebook->save();

        $hire->save();

        return \response()->json(['message' => 'success', 'data' => $hire->toArray()], 200);
    }

    public function getType(Request $request)
    {
        $types = \App\Type::all();

        return response()->json([
            'message' => 'success',
            'data' => $types,
        ]);
    }
}
