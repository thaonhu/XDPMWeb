﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DemoAdminPPP.Common
{
    public static class CommonContants
    {
        public static string USER_SESSION = "USER_SESSION";
    }
}