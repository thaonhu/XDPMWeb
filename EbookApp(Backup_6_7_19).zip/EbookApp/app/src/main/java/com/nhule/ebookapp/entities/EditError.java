package com.nhule.ebookapp.entities;

import java.util.List;
import java.util.Map;

public class EditError {
    String message;
    Map<String, List<String>> error;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public void setError(Map<String, List<String>> error) {
        this.error = error;
    }

    public Map<String, List<String>> getError() {
        return error;
    }
}
