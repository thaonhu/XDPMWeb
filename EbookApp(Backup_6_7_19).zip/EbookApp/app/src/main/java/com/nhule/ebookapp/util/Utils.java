package com.nhule.ebookapp.util;

import com.nhule.ebookapp.entities.ApiError;
import com.nhule.ebookapp.entities.EditError;
import com.nhule.ebookapp.network.RetrofitBuilder;

import java.io.IOException;
import java.lang.annotation.Annotation;

import okhttp3.ResponseBody;
import retrofit2.Converter;

public class Utils {

    public ApiError convertErrors(ResponseBody response, RetrofitBuilder retrofitBuilder){
        Converter<ResponseBody, ApiError> converter = retrofitBuilder.getRetrofit().responseBodyConverter(ApiError.class,new Annotation[0]);

        ApiError apiError = null;
        try {
            apiError =  converter.convert(response);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return apiError;
    }

    public EditError convertEditErrors(ResponseBody response, RetrofitBuilder retrofitBuilder){
        Converter<ResponseBody, EditError> converter = retrofitBuilder.getRetrofit().responseBodyConverter(EditError.class,new Annotation[0]);

        EditError editError = null;
        try {
            editError = converter.convert(response);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return editError;
    }
}
