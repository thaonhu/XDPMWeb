package com.nhule.ebookapp.model;

public class FindHistory {
    int id;
    String findContent;

    public FindHistory() {
    }

    public FindHistory(int id, String findContent) {
        this.id = id;
        this.findContent = findContent;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFindContent() {
        return findContent;
    }

    public void setFindContent(String findContent) {
        this.findContent = findContent;
    }
}
