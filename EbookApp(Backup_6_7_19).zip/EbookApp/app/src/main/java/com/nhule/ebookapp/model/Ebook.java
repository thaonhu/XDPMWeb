package com.nhule.ebookapp.model;

public class Ebook {
    int id;
    String name;
    String description;
    int rate;
    String linkContent;
    int pageNuber;
    String image;
    int hirePrice;
    int price;
    int isnew;

    public Ebook() {
    }

    public Ebook(int id, String name, String description, int rate, String linkContent, int pageNuber, String image, int hirePrice, int price, int isnew) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.rate = rate;
        this.linkContent = linkContent;
        this.pageNuber = pageNuber;
        this.image = image;
        this.hirePrice = hirePrice;
        this.price = price;
        this.isnew = isnew;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getRate() {
        return rate;
    }

    public void setRate(int rate) {
        this.rate = rate;
    }

    public String getLinkContent() {
        return linkContent;
    }

    public void setLinkContent(String linkContent) {
        this.linkContent = linkContent;
    }

    public int getPageNuber() {
        return pageNuber;
    }

    public void setPageNuber(int pageNuber) {
        this.pageNuber = pageNuber;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public int getHirePrice() {
        return hirePrice;
    }

    public void setHirePrice(int hirePrice) {
        this.hirePrice = hirePrice;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getIsnew() {
        return isnew;
    }

    public void setIsnew(int isnew) {
        this.isnew = isnew;
    }

}
