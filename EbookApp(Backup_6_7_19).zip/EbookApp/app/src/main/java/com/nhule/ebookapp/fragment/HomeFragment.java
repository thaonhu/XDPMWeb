package com.nhule.ebookapp.fragment;


import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.nhule.ebookapp.R;
import com.nhule.ebookapp.adapter.RecycleHorizontalViewAdapter;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends Fragment {

    private static final String TAG = "HOME";

    private RecyclerView ebook_list_view;

    RecyclerView.LayoutManager mLayoutManager;

    //vars

    private ArrayList<String> listName = new ArrayList<>();
    private ArrayList<String> listImage = new ArrayList<>();
    private ArrayList<Integer> listPrice = new ArrayList<>();
    private ArrayList<Integer> listHirePrice = new ArrayList<>();

    public HomeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        TextView textView = new TextView(getActivity());
        textView.setText(R.string.hello_blank_fragment);
        View view= inflater.inflate(R.layout.fragment_home,container,false);

        ebook_list_view = getActivity().findViewById(R.id.home_hor);
        ebook_list_view.setLayoutManager();
        initImageBitmap();
        return view;
    }

    private void initImageBitmap(){
        Log.d(TAG, "initImageBitmap: imag link ");

        listImage.add("https://ibb.co/py5BzLY");
        listHirePrice.add(22222);
        listName.add("aaaaaaaaaa");
        listPrice.add(333333);

        listImage.add("https://ibb.co/py5BzLY");
        listHirePrice.add(22222);
        listName.add("dddddddd");
        listPrice.add(333333);

        listImage.add("https://ibb.co/py5BzLY");
        listHirePrice.add(22222);
        listName.add("dsssssss");
        listPrice.add(333333);

        listImage.add("https://ibb.co/py5BzLY");
        listHirePrice.add(22222);
        listName.add("qqqqqqqq");
        listPrice.add(333333);

        initRecycleView();
    }

    private void initRecycleView(){
        Log.d(TAG, "initRecycleView: init");
        mLayoutManager = new LinearLayoutManager(getActivity());
//        ebook_list_view.setAdapter(RecycleHorizontalViewAdapter);
        ebook_list_view.setLayoutManager(mLayoutManager);

        initRecycleView();
        LinearLayoutManager layoutManager = new LinearLayoutManager(HomeFragment.this, LinearLayoutManager.HORIZONTAL, false);
    }
}
