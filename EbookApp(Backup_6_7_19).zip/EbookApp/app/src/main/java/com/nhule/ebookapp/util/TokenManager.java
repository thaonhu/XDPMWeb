package com.nhule.ebookapp.util;

import android.content.SharedPreferences;

import com.nhule.ebookapp.entities.AccessToken;

public class TokenManager {

    private SharedPreferences prefs;
    private SharedPreferences.Editor editor;
    private static TokenManager INTANCE = null;

    private TokenManager(SharedPreferences prefs){
        this.prefs = prefs;
        this.editor = prefs.edit();
    }
    public static synchronized TokenManager getInstance(SharedPreferences prefs){

        if(INTANCE ==null){
            INTANCE = new TokenManager(prefs);
        }
        return INTANCE;
    }

    //luu token
    public void saveToken(AccessToken token){

        editor.putString("ACCESS_TOKEN", token.getAccessToken()).commit();
        editor.putString("TOKEN_TYPE", token.getTokenType()).commit();

    }

    //xoa token
    public void deleteToken(AccessToken token){
        editor.remove("ACCESS_TOKEN").commit();
        editor.remove("TOKEN_TYPE").commit();
    }

    //lay token
    public AccessToken getToken(){
        AccessToken token = new AccessToken();

        token.setAccessToken(prefs.getString("ACCESS_TOKEN",null));

        token.setTokenType(prefs.getString("TOKEN_TYPE",null));
        return token;
    }
}
