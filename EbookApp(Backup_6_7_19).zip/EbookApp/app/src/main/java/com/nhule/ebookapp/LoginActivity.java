package com.nhule.ebookapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.widget.Toast;

import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;
import com.google.android.material.textfield.TextInputLayout;
import com.nhule.ebookapp.entities.AccessToken;
import com.nhule.ebookapp.entities.ApiError;
import com.nhule.ebookapp.model.User;
import com.nhule.ebookapp.network.ApiService;
import com.nhule.ebookapp.network.RetrofitBuilder;
import com.nhule.ebookapp.util.Database;
import com.nhule.ebookapp.util.TokenManager;
import com.nhule.ebookapp.util.Utils;

import java.util.List;
import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {

    private static final String TAG = "LoginActivity";

    SharedPreferences sharedPreferences;

    @BindView(R.id.login_till_mail)
    TextInputLayout txtMail;
    @BindView(R.id.login_till_pass)
    TextInputLayout txtPass;

    ApiService service;
    Call<AccessToken> call;

    RetrofitBuilder retrofit = new RetrofitBuilder();
    AwesomeValidation validation;

    final String DATABASE_NAME = "DbEbook.db";
    SQLiteDatabase database;
    // token
    TokenManager tokenManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        ButterKnife.bind(this);

        service = retrofit.createService(ApiService.class);

        validation = new AwesomeValidation(ValidationStyle.TEXT_INPUT_LAYOUT);
        tokenManager = TokenManager.getInstance(getSharedPreferences("prefs", MODE_PRIVATE));
        setupRules();
    }

    @OnClick(R.id.login_regLogin_btn)
    void reg() {
        Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
        startActivity(intent);
        finish();
    }

    @OnClick(R.id.login_btn)
    void login() {

        String mail = txtMail.getEditText().getText().toString();
        String pass = txtPass.getEditText().getText().toString();

        txtMail.setError(null);
        txtPass.setError(null);

        validation.clear();

        if (validation.validate()) {
            call = service.login(mail, pass);

            call.enqueue(new Callback<AccessToken>() {
                @Override
                public void onResponse(Call<AccessToken> call, Response<AccessToken> response) {
                    Toast.makeText(LoginActivity.this, "response: " + response, Toast.LENGTH_SHORT).show();

                    if (response.isSuccessful()) {
                        Toast.makeText(LoginActivity.this, R.string.login_account_success, Toast.LENGTH_SHORT).show();

                        tokenManager.saveToken(response.body());
                        AccessToken accessToken = tokenManager.getToken();
//                        Log.w(TAG, "onResponse: " + response.body());

                        String token = accessToken.getAccessToken();
                        SharedPreferences sharedPreferences = getSharedPreferences("prefs", Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putString("token",token);
                        editor.apply();

                        User user = response.body().getUser();

                        if(user != null){
                            saveUser(user);
                        }

                        Toast.makeText(LoginActivity.this, user.getName(), Toast.LENGTH_SHORT).show();

                        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                        intent.putExtra("token", token);
//                        intent.putExtra("user", user);
                        startActivity(intent);
                    } else {

                        handleErrors(response.errorBody());
                    }
                }

                @Override
                public void onFailure(Call<AccessToken> call, Throwable t) {

                    //Log.w(TAG, "onFailure: " + t.getMessage());
                    Toast.makeText(LoginActivity.this, R.string.login_account_failed, Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    private void handleErrors(ResponseBody response) {

        ApiError apiError = new Utils().convertErrors(response, retrofit);

        for (Map.Entry<String, List<String>> error : apiError.getError().entrySet()) {

            if (error.getKey().equals("email")) {
                txtMail.setError(error.getValue().get(0));
            }
            if (error.getKey().equals("password")) {
                txtPass.setError(error.getValue().get(0));
            }
        }
    }

    public void setupRules() {
        validation.addValidation(LoginActivity.this, R.id.reg_till_mail, Patterns.EMAIL_ADDRESS, R.string.err_mail);
        validation.addValidation(LoginActivity.this, R.id.reg_till_pass, "[a-zA-Z0-9]{6,}", R.string.err_pass);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (call != null) {
            call.cancel();
            call = null;
        }
    }

    public Boolean saveUser(User user) {
        database = Database.initDatabase(LoginActivity.this, DATABASE_NAME);

//        database.beginTransaction();
        int ma = user.getId();
        Cursor cursor = database.rawQuery("SELECT * FROM User WHERE id=?", new String[]{user.getId() + ""});
        //cursor.moveToFirst();
        if (cursor.moveToFirst()) {
            //database.delete("User","id=?",new String[]{ma+""});
            return false;
        } else {
            ContentValues contentValues = new ContentValues();
            contentValues.put("id", user.getId());
            contentValues.put("username", user.getName());
            contentValues.put("email", user.getEmail());
            contentValues.put("image", user.getImage());
            contentValues.put("phone", user.getPhone());
            contentValues.put("money", user.getMoney());
            contentValues.put("update_at", user.getUpdate_at());
            contentValues.put("create_at", user.getCreate_at());

            database = Database.initDatabase(this, DATABASE_NAME);
            long i = database.insert("User", null, contentValues);
            if (i != 0) {
                Toast.makeText(this, "thanh cong", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "meo thanh cong nha", Toast.LENGTH_SHORT).show();
                return false;
            }
            return true;
        }
    }
}
