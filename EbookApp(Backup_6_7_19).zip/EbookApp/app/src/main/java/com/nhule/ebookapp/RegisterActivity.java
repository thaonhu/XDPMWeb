package com.nhule.ebookapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.Toast;

import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;
import com.basgeekball.awesomevalidation.utility.RegexTemplate;
import com.google.android.material.textfield.TextInputLayout;
import com.nhule.ebookapp.entities.AccessToken;
import com.nhule.ebookapp.entities.ApiError;
import com.nhule.ebookapp.network.ApiService;
import com.nhule.ebookapp.network.RetrofitBuilder;
import com.nhule.ebookapp.util.Utils;

import java.util.List;
import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegisterActivity extends AppCompatActivity {

    private static final String TAG = "RegisterActivity";

    @BindView(R.id.reg_till_mail)
    TextInputLayout txtMail;
    @BindView(R.id.reg_till_name)
    TextInputLayout txtName;
    @BindView(R.id.reg_till_pass)
    TextInputLayout txtPass;
    @BindView(R.id.reg_till_pass_confim)
    TextInputLayout txtPassConfim;

    ApiService service;
    Call<AccessToken> call;
    AwesomeValidation validation;
    RetrofitBuilder retrofit = new RetrofitBuilder();

    //TokenManager tokenManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        ButterKnife.bind(this);
        // neu can token: .setToken("XXXXX")
        service = retrofit.createService(ApiService.class);
        validation = new AwesomeValidation(ValidationStyle.TEXT_INPUT_LAYOUT);

        //tokenManager = TokenManager.getInstance(getSharedPreferences("prefs", MODE_PRIVATE));
        setupRules();
    }

    @OnClick(R.id.reg_btn_account)
    void Register() {

        String name = txtName.getEditText().getText().toString();
        String mail = txtMail.getEditText().getText().toString();
        String pass = txtPass.getEditText().getText().toString();
        String passConfim = txtPassConfim.getEditText().getText().toString();

        txtName.setError(null);
        txtMail.setError(null);
        txtPass.setError(null);
        txtPassConfim.setError(null);

        validation.clear();

        if (validation.validate()) {
            call = service.signup(name, mail, pass);

            call.enqueue(new Callback<AccessToken>() {
                @Override
                public void onResponse(Call<AccessToken> call, Response<AccessToken> response) {

                    //Toast.makeText(RegisterActivity.this, "response: " + response, Toast.LENGTH_SHORT).show();
                    if (response.isSuccessful()) {

                        Toast.makeText(RegisterActivity.this, R.string.create_account_success, Toast.LENGTH_SHORT).show();

                        //tokenManager.saveToken(response.body());

                        Intent intent = new Intent(RegisterActivity.this,MainActivity.class);
                        startActivity(intent);

                    } else {
                        handleErrors(response.errorBody());
                    }
                }

                @Override
                public void onFailure(Call<AccessToken> call, Throwable t) {

                    Toast.makeText(RegisterActivity.this, R.string.create_account_failed, Toast.LENGTH_SHORT).show();
                    //Log.w(TAG, "onFailure: " + t.getMessage());
                }
            });
        }
    }

    @OnClick(R.id.reg_btn_login)
    void login(){
        Intent intent = new Intent(RegisterActivity.this,MainActivity.class);
        startActivity(intent);
    }

    private void handleErrors(ResponseBody response) {

        ApiError apiError = new Utils().convertErrors(response, retrofit);

        for (Map.Entry<String, List<String>> error : apiError.getError().entrySet()) {

            if (error.getKey().equals("name")) {
                txtName.setError(error.getValue().get(0));
            }
            if (error.getKey().equals("email")) {
                txtMail.setError(error.getValue().get(0));
            }
            if (error.getKey().equals("password")) {
                txtPass.setError(error.getValue().get(0));
            }
        }

    }

    public void setupRules() {

        validation.addValidation(RegisterActivity.this, R.id.reg_till_name, RegexTemplate.NOT_EMPTY, R.string.err_name);
        validation.addValidation(RegisterActivity.this, R.id.reg_till_mail, Patterns.EMAIL_ADDRESS, R.string.err_mail);
        validation.addValidation(RegisterActivity.this, R.id.reg_till_pass, "[a-zA-Z0-9]{6,}", R.string.err_pass);

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (call != null) {
            call.cancel();
            call = null;
        }
    }
}
