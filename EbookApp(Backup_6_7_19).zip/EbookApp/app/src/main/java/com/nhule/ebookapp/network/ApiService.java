package com.nhule.ebookapp.network;

import com.nhule.ebookapp.entities.AccessToken;
import com.nhule.ebookapp.entities.EditUser;
import com.nhule.ebookapp.entities.GetUser;
import com.nhule.ebookapp.entities.Register;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface ApiService {
    @FormUrlEncoded
    @POST("signup")
    public Call<AccessToken> signup(@Field("name") String name, @Field("email") String email, @Field("password") String password);

    @FormUrlEncoded
    @POST("login")
    public  Call<AccessToken> login(@Field("email") String email, @Field("password") String password);

    @FormUrlEncoded
    @POST("user/edit")
    public  Call<EditUser> editUser(@Field("name") String name, @Field("password") String pass,@Field("email") String email, @Field("img") String img, @Field("phone") String phone);

//get user
    @FormUrlEncoded
    @POST("user")
    public Call<GetUser> getUserByToken(@Field("token") String token);

    @FormUrlEncoded
    @POST("logout")
    public Call<Register> logout();

}
