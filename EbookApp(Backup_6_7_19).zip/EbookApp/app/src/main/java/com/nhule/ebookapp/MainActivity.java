package com.nhule.ebookapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.nhule.ebookapp.entities.AccessToken;
import com.nhule.ebookapp.entities.GetUser;
import com.nhule.ebookapp.fragment.HomeFragment;
import com.nhule.ebookapp.fragment.LibraryFragment;
import com.nhule.ebookapp.model.User;
import com.nhule.ebookapp.network.ApiService;
import com.nhule.ebookapp.network.RetrofitBuilder;
import com.nhule.ebookapp.util.Database;
import com.nhule.ebookapp.util.TokenManager;
import com.squareup.haha.perflib.Main;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private Toolbar toolbar;

    User user;
    String token;
    TokenManager tokenManager;

    RetrofitBuilder retrofit = new RetrofitBuilder();
    ApiService service;
    Call<GetUser> call;


//    final String DATABASE_NAME = "DbEbook.db";
//    SQLiteDatabase database;

//    SliderAdapter sliderLayout;

    BottomNavigationView mainBottomView;
    private HomeFragment homeFragment;
    private LibraryFragment libraryFragment;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Fragment

        homeFragment = new HomeFragment();
        libraryFragment = new LibraryFragment();

        // bottom menu
        mainBottomView = findViewById(R.id.main_bottom_navigation);

        mainBottomView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.btn_action_home:
                        replaceFragment(homeFragment);
                        return true;
                    case R.id.btn_library:
                        replaceFragment(libraryFragment);
                        return true;
                    default:
                        return false;
                }
            }
        });
        // bottommmmmmmmmmmmm

        //toolbarrrrrrrrrrrrrrr
        toolbar = findViewById(R.id.main_Toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Ebook App");
        //tolbarrrrrrrrrrrrrrrr

        token = getToken();

        retrofit.setToken(token);
        service = retrofit.createService(ApiService.class);

//        tokenManager = TokenManager.getInstance(getSharedPreferences("prefs", MODE_PRIVATE));
//        AccessToken accessToken = tokenManager.getToken();
//        token = accessToken.getAccessToken();

        if(token!=null){
            getUser(token);    
        }else {
            Toast.makeText(this, "ma no loi hoai!", Toast.LENGTH_SHORT).show();

        }
        
        //Toast.makeText(MainActivity.this, ""+user.getCreate_at(), Toast.LENGTH_SHORT).show();

//        Toast.makeText(this, "mas: " + id, Toast.LENGTH_SHORT).show();

    }

    @Override
    protected void onStart() {
        super.onStart();

//        AccessToken kttoken = getToken();
//
//        if(kttoken == null || user == null){
//            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
//            startActivity(intent);
//            finish();
//        }else{
//
//            token = getIntent().getStringExtra("token");
//            Toast.makeText(this, "do dc", Toast.LENGTH_SHORT).show();
//            user = (User) getIntent().getSerializableExtra("user");
////            saveUser(user);
//        }
        // de bien kiem tra dang nhap do
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    public void logOut() {
        // bien sharereference = false;

        sentToLogin();
    }

    private void sentToLogin() {

        Intent intent = new Intent(MainActivity.this, LoginActivity.class);
        startActivity(intent);

        finish();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_bar_search:
                break;
            case R.id.menu_action_Logout:
                logOut();
                break;
            case R.id.menu_action_Setting:
                Intent intent = new Intent(MainActivity.this, SetupActivity.class);
//                intent.putExtra("token",token);
                intent.putExtra("user", user);
                startActivity(intent);
                break;
        }
        return true;
    }

//    public Boolean saveUser(User user) {
//        database = Database.initDatabase(MainActivity.this, DATABASE_NAME);
//
////        database.beginTransaction();
//        int ma = user.getId();
//        Cursor cursor = database.rawQuery("SELECT * FROM User WHERE id=?", new String[]{user.getId() + ""});
//        //cursor.moveToFirst();
//        if (cursor.moveToFirst()) {
//            //database.delete("User","id=?",new String[]{ma+""});
//            return false;
//        } else {
//            ContentValues contentValues = new ContentValues();
//            contentValues.put("id", user.getId());
//            contentValues.put("username", user.getName());
//            contentValues.put("email", user.getEmail());
//            contentValues.put("image", user.getImage());
//            contentValues.put("phone", user.getPhone());
//            contentValues.put("money", user.getMoney());
//            contentValues.put("update_at", user.getUpdate_at());
//            contentValues.put("create_at", user.getCreate_at());
//
//            database = Database.initDatabase(this, DATABASE_NAME);
//            long i = database.insert("User", null, contentValues);
//            if (i != 0) {
//                Toast.makeText(this, "thanh cong", Toast.LENGTH_SHORT).show();
//            } else {
//                Toast.makeText(this, "meo thanh cong nha", Toast.LENGTH_SHORT).show();
//                return false;
//            }
////        database.close();
//            return true;
//        }
//    }

    private void replaceFragment(Fragment fragment) {
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.main_Container, fragment);
        fragmentTransaction.commit();

    }


    public void getUser(String token) {
        call = service.getUserByToken(token);
        call.enqueue(new Callback<GetUser>() {
            @Override
            public void onResponse(Call<GetUser> call, Response<GetUser> response) {
//                Log.w(TAG, "onResponse: "+response,null );

                if (response.isSuccessful()) {
                    //Toast.makeText(SetupActivity.this, "resssss" + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    //Toast.makeText(SetupActivity.this, "respone: ", Toast.LENGTH_SHORT).show();

                    //load tat ca len view
                    user = response.body().getUser();

                    Toast.makeText(MainActivity.this, "respone: " + user.getName(), Toast.LENGTH_SHORT).show();
//                    loadDT(response.body().getUser());

                } else {
                    Toast.makeText(MainActivity.this, "deo dc", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                    startActivity(intent);
                    finish();

                }
            }

            @Override
            public void onFailure(Call<GetUser> call, Throwable t) {
                Toast.makeText(MainActivity.this, "da failllllt", Toast.LENGTH_SHORT).show();
                Log.w("fffffffff", "onFailure: " + t.getMessage());

                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });

    }

    public String getToken() {
        tokenManager = TokenManager.getInstance(getSharedPreferences("prefs", MODE_PRIVATE));
        AccessToken accessToken = tokenManager.getToken();
        String mToken = accessToken.getAccessToken();
        return mToken;
    }
}
