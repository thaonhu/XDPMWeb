package com.nhule.ebookapp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.util.Patterns;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;
import com.basgeekball.awesomevalidation.utility.RegexTemplate;
import com.google.android.material.textfield.TextInputLayout;
import com.nhule.ebookapp.entities.AccessToken;
import com.nhule.ebookapp.entities.EditError;
//import com.nhule.ebookapp.entities.EditError;
import com.nhule.ebookapp.entities.EditUser;
import com.nhule.ebookapp.entities.GetUser;
import com.nhule.ebookapp.model.User;
import com.nhule.ebookapp.network.ApiService;
import com.nhule.ebookapp.network.RetrofitBuilder;
import com.nhule.ebookapp.util.Database;
import com.nhule.ebookapp.util.TokenManager;
import com.nhule.ebookapp.util.Utils;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import de.hdodenhof.circleimageview.CircleImageView;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class SetupActivity extends AppCompatActivity {

    @BindView(R.id.setup_till_name)
    TextInputLayout tillName;
    @BindView(R.id.setup_name)
    TextView txtName;
    @BindView(R.id.setup_till_mail)
    TextInputLayout tillMail;
    @BindView(R.id.setup_mail)
    TextView txtMail;
    @BindView(R.id.setup_till_phone)
    TextInputLayout tillPhone;
    @BindView(R.id.setup_phone)
    TextView txtPhone;
    @BindView(R.id.setup_till_pass)
    TextInputLayout tillPass;
    @BindView(R.id.setup_pass)
    TextView txtPass;
    @BindView(R.id.setup_btn_money)
    Button btnGetMoney;
    @BindView(R.id.setup_btn_save)
    Button btnSave;
    @BindView(R.id.setup_money)
    TextView txtMoney;

    private CircleImageView setupImage;
    Uri uri;

    SQLiteDatabase database;
    TokenManager tokenManager;
    final String DATABASE_NAME = "DbEbook.db";

    ApiService service;
    Call<GetUser> call;
    Call<EditUser> callEdit;

    User user;
    String token;

    private Toolbar toolbar;

    private static final String BASE_URL = "http://10.0.2.2/demolaravel/public/api/";
    private static final String TAG = "dddddd";

    RetrofitBuilder retrofit = new RetrofitBuilder();
    AwesomeValidation validation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setup);

        ButterKnife.bind(this);

        token = getToken();
        retrofit.setToken(token);
        service = retrofit.createService(ApiService.class);
        validation = new AwesomeValidation(ValidationStyle.TEXT_INPUT_LAYOUT);

        setupImage = findViewById(R.id.setup_image);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Ebook App");
        getUser(token);

        setupRules();

    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    public String getToken() {
        tokenManager = TokenManager.getInstance(getSharedPreferences("prefs", MODE_PRIVATE));
        AccessToken accessToken = tokenManager.getToken();
        String mToken = accessToken.getAccessToken();
        return mToken;
    }

    public void getUser(String token) {
        call = service.getUserByToken(token);
        call.enqueue(new Callback<GetUser>() {
            @Override
            public void onResponse(Call<GetUser> call, Response<GetUser> response) {
//                Log.w(TAG, "onResponse: "+response,null );

                if (response.isSuccessful()) {
                    //Toast.makeText(SetupActivity.this, "resssss" + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    //Toast.makeText(SetupActivity.this, "respone: ", Toast.LENGTH_SHORT).show();

                    //load tat ca len view
                    user = response.body().getUser();

                    Toast.makeText(SetupActivity.this, "respone: " + user.getName(), Toast.LENGTH_SHORT).show();
                    loadDT(response.body().getUser());

                } else {
                    Toast.makeText(SetupActivity.this, "deo dc", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(SetupActivity.this, LoginActivity.class);
                    startActivity(intent);
                    finish();

                }
            }

            @Override
            public void onFailure(Call<GetUser> call, Throwable t) {
                Toast.makeText(SetupActivity.this, "da failllllt", Toast.LENGTH_SHORT).show();
                Log.w(TAG, "onFailure: " + t.getMessage());
            }
        });

    }

    @OnClick(R.id.setup_image)
    void imageClick() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(SetupActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {

                Toast.makeText(SetupActivity.this, "Permission Dennied", Toast.LENGTH_SHORT).show();
                ActivityCompat.requestPermissions(SetupActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 1);

            } else {
                Toast.makeText(SetupActivity.this, "Permission OK!", Toast.LENGTH_SHORT).show();
                BringImagePicker();
            }
        } else {
            BringImagePicker();
        }

    }

    private String convertToEncodeBase64() {

        if (uri != null) {
            Bitmap bm = BitmapFactory.decodeFile(uri.getPath());
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            bm.compress(Bitmap.CompressFormat.JPEG, 100, baos); //bm is the bitmap object
            byte[] b = baos.toByteArray();

            String encodedImage = Base64.encodeToString(b, Base64.DEFAULT);
            return encodedImage;
        }
        return null;


    }

    private void BringImagePicker() {
        CropImage.activity()
                .setGuidelines(CropImageView.Guidelines.ON)
                .setAspectRatio(1, 1)
                .start(SetupActivity.this);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (resultCode == RESULT_OK) {

                uri = result.getUri();
                setupImage.setImageURI(uri);
                // lấy đc uri r
                // lấy img đưa lên app

//                Bitmap bitmap = null;
//                try {
//                    bitmap = BitmapFactory.decodeStream((InputStream)new URL(uri).getContent());
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//                setupImage.setImageBitmap(bitmap);

                // get image url
//                String image = task.getResult().toString();
//                RequestOptions placeholderRequest = new RequestOptions();
//                placeholderRequest.placeholder(R.mipmap.default_image);
//
//                // show to view
//                Glide.with(SetupActivity.this).setDefaultRequestOptions(placeholderRequest).load(image).into(setupImage);

            } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                Exception error = result.getError();
                Toast.makeText(SetupActivity.this, "" + error, Toast.LENGTH_SHORT).show();
            }
        }
    }

    @OnClick(R.id.setup_btn_save)
    void save() {

        token = getToken();
        retrofit.setToken(token);
        service = retrofit.createService(ApiService.class);
        String img = convertToEncodeBase64();

        String name = txtName.getText().toString();
        String email = txtMail.getText().toString();
//        String img =
        String pass = txtPass.getText().toString();
        String phone = txtPhone.getText().toString();

        txtName.setError(null);
        txtMail.setError(null);
        txtPass.setError(null);
        txtPhone.setError(null);

        validation.clear();

        // update len server
        if(validation.validate()) {


            callEdit = service.editUser(name, pass, email, img, phone);
            callEdit.enqueue(new Callback<EditUser>() {
                @Override
                public void onResponse(Call<EditUser> call, Response<EditUser> response) {
                    Log.w(TAG, "onResponse: " + response.message(), null);
                    if (response.isSuccessful()) {
                        User userUpdate = response.body().getUser();
                        Toast.makeText(SetupActivity.this, "dc r" + userUpdate.getName(), Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(SetupActivity.this, "deo duoc!!!", Toast.LENGTH_SHORT).show();
                        handleErrors(response.errorBody());
                    }
                }

                @Override
                public void onFailure(Call<EditUser> call, Throwable t) {
                    Log.w(TAG, "onFailure: " + t.getMessage());
                }
            });
        }
        //update len db
//        ContentValues contentValues = new ContentValues();
//
//        contentValues.put("username", name);
//        contentValues.put("email", email);
////        contentValues.put("image", user.getImage());
//        contentValues.put("phone", phone);
//
//        database = Database.initDatabase(this, DATABASE_NAME);
//        long i = database.update("User", contentValues, "id=?", new String[]{user.getId() + ""});

//        if (updateDB()) {
//
//
//
//        } else {
//
//        }
    }


    private class LoadImageServer extends AsyncTask<String, Void, Bitmap> {

        Bitmap bitmap = null;

        @Override
        protected Bitmap doInBackground(String... strings) {

            try {
                URL url = new URL(strings[0]);

                InputStream inputStream = url.openConnection().getInputStream();

                bitmap = BitmapFactory.decodeStream(inputStream);

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return bitmap;
        }

        @Override
        protected void onPostExecute(Bitmap result) {
            super.onPostExecute(result);
            setupImage.setImageBitmap(result);
        }
    }

    // replace link anh
    //public String replace (CharSequence target, CharSequence replacement);
    // link ảnh trên postman: http://127.0.0.1:8000/backend/image/user/21.jpg
    // link ảnh dúng : http://10.0.2.2/demolaravel/public/backend/image/user/21.jpg
    private void loadDT(User user) {

        if (user.getImage() != null) {
            String str = user.getImage();
            str.replace("http://10.0.2.2/demolaravel/public", "http://127.0.0.1:8000");
            new LoadImageServer().execute(str);
        }
        txtMail.setText(user.getEmail());
        txtName.setText(user.getName());
        if (user.getPhone() != null) {
            txtPhone.setText(user.getPhone());
        } else {
            txtPhone.setText("");
        }
        txtMoney.setText(user.getMoney() + "");
    }

    private void handleErrors(ResponseBody response) {

        EditError editError = new Utils().convertEditErrors(response,retrofit);

        for (Map.Entry<String, List<String>> error : editError.getError().entrySet()) {

            if (error.getKey().equals("name")) {
                txtName.setError(error.getValue().get(0));
            }
            if (error.getKey().equals("email")) {
                txtMail.setError(error.getValue().get(0));
            }
            if (error.getKey().equals("password")) {
                txtPass.setError(error.getValue().get(0));
            }
            if(error.getKey().equals("phone")){
                txtPhone.setError(error.getValue().get(0));
            }
        }

    }
    public void setupRules() {

        validation.addValidation(SetupActivity.this, R.id.setup_till_name, RegexTemplate.NOT_EMPTY, R.string.err_name);
        validation.addValidation(SetupActivity.this, R.id.setup_till_mail, Patterns.EMAIL_ADDRESS, R.string.err_mail);
        validation.addValidation(SetupActivity.this, R.id.setup_till_pass, "[a-zA-Z0-9]{6,}", R.string.err_pass);
        validation.addValidation(SetupActivity.this,R.id.setup_till_phone,"[0-9]{9,}",R.string.err_phone);

    }

}
