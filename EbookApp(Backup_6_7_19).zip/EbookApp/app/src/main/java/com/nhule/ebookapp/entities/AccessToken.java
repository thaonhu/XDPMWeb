package com.nhule.ebookapp.entities;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.nhule.ebookapp.model.User;
import com.squareup.moshi.Json;

import java.util.Date;

public class AccessToken {


    @SerializedName("message")
    @Expose
    String message;
    @SerializedName("access_token")
    @Expose
    String accessToken;
    @SerializedName("token_type")
    @Expose
    String tokenType;
    @SerializedName("expires_at")
    @Expose
    String expires_at;
    @SerializedName("user")
    @Expose
    User user;

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getTokenType() {
        return tokenType;
    }

    public void setTokenType(String tokenType) {
        this.tokenType = tokenType;
    }

    public String getExpires_at() {
        return expires_at;
    }

    public void setExpires_at(String expires_at) {
        this.expires_at = expires_at;
    }


//    public User getUser() {
//        return user;
//    }
//
//    public void setUser(User user) {
//        this.user = user;
//    }
}
