package com.nhule.ebookapp.entities;

import java.util.List;
import java.util.Map;

public class ApiError {

    Map<String, List<String>> error;

    public Map<String, List<String>> getError() {
        return error;
    }
}
