package com.nhule.ebookapp.entities;

public class Register {

    public String getMassage() {
        return massage;
    }

    public void setMassage(String massage) {
        this.massage = massage;
    }

    private String massage;
}
