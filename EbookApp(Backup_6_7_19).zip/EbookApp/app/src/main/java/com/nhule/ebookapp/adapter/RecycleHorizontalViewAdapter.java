package com.nhule.ebookapp.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.nhule.ebookapp.R;

import java.util.ArrayList;

public class RecycleHorizontalViewAdapter extends RecyclerView.Adapter<RecycleHorizontalViewAdapter.ViewHoler> {
    private static final String TAG = "RecycleHorizontalViewAd";

    //vars
    private ArrayList<String> listName = new ArrayList<>();
    private ArrayList<String> listImage = new ArrayList<>();
    private ArrayList<Integer> listPrice = new ArrayList<>();
    private ArrayList<Integer> listHirePrice = new ArrayList<>();

    private Context context;

    public RecycleHorizontalViewAdapter(ArrayList<String> listName, ArrayList<String> listImage, ArrayList<Integer> listPrice, ArrayList<Integer> listHirePrice, Context context) {

        this.listName = listName;
        this.listImage = listImage;
        this.listPrice = listPrice;
        this.listHirePrice = listHirePrice;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHoler onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        Log.d(TAG, "onCreateViewHolder: called");
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.main_list_item,parent, false);
        return new ViewHoler(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHoler holder, int position) {
        Log.d(TAG, "onBindViewHolder: called");

        Glide.with(context)
                .asBitmap()
                .load(listImage.get(position))
                .into(holder.img);
        holder.txtName.setText(listName.get(position));
        holder.txtPrice.setText(listPrice.get(position)+"");
        holder.txtHirePrice.setText(listHirePrice.get(position)+"");

        holder.img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick: click on image" +listName.get(position));

                Toast.makeText(context, "name: "+listName.get(position), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return listName.size();
    }

    public class ViewHoler extends RecyclerView.ViewHolder{
        ImageView img;
        Button btnRent;
        TextView txtName, txtPrice, txtHirePrice;

        public ViewHoler(@NonNull View itemView) {
            super(itemView);

            img = itemView.findViewById(R.id.main_img);
            btnRent = itemView.findViewById(R.id.main_btn_rent);
            txtName = itemView.findViewById(R.id.main_name);
            txtPrice = itemView.findViewById(R.id.main_price);
            txtHirePrice = itemView.findViewById(R.id.main_hireprice);


        }
    }
}
