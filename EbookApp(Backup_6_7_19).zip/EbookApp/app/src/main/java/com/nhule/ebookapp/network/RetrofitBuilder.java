package com.nhule.ebookapp.network;

import com.facebook.stetho.okhttp3.StethoInterceptor;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.nhule.ebookapp.BuildConfig;

import java.io.IOException;

import okhttp3.Credentials;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitBuilder {

    private String token = null;
    // emulator to localhost
    private static final String BASE_URL = "http://10.0.2.2/demolaravel/public/api/";
    // real mobile to localhost
//    private static final String BASE_URL = "192.168.1.11//demolaravel/public/api/";

    public RetrofitBuilder setToken(String token) {
        if (token!=null) {
            this.token = token;
        }
        return this;
    }

    private final OkHttpClient client = BuildClient();
    private final Retrofit retrofit = buildRetrofit(client);

    private OkHttpClient BuildClient(){
        OkHttpClient.Builder builder = new OkHttpClient().newBuilder().addInterceptor(new Interceptor() {
            @Override
            public Response intercept(Chain chain) throws IOException {
                Request request = chain.request();
                // header token sau khi login nhé
                Request.Builder builder = request.newBuilder()
                        .addHeader("Accept","application/json");


                if (token!=null) {
                        builder.addHeader("Authorization", "Bearer " + token);


                }
//
//                .addHeader("Authorization", "Bearer " + token);
//                .addHeader("connection","close");
                request = builder.build();

                return chain.proceed(request);
            }
        });

        if(BuildConfig.DEBUG){
            builder.addNetworkInterceptor(new StethoInterceptor());
        }

        return builder.build();
    }


    private Retrofit buildRetrofit(OkHttpClient client){
        Gson gson = new GsonBuilder()
                .setLenient()
                .create();

        return new Retrofit.Builder().baseUrl(BASE_URL).client(client).addConverterFactory(GsonConverterFactory.create()).build();
        //return new Retrofit.Builder().baseUrl(BASE_URL).client(client).addConverterFactory(MoshiConverterFactory.create()).build();
    }
    public <T> T createService(Class<T> service) // api service class
    {
        return retrofit.create(service);
    }

    public Retrofit getRetrofit() {
        return retrofit;
    }
}
