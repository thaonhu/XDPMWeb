package com.nhule.ebookapp.model;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

public class User implements Serializable {

    int id;
    String name;
    String email;
    String img;
    String phone;
    int money;
    String create_at;
    String update_at;

//    Date create_at;
//    Date upsate_at;

//    public Date getCreate_at() {
//        return create_at;
//    }
//
//    public void setCreate_at(Date create_at) {
//        this.create_at = create_at;
//    }
//
//    public Date getUpsate_at() {
//        return upsate_at;
//    }
//
//    public void setUpsate_at(Date upsate_at) {
//        this.upsate_at = upsate_at;
//    }

    public User() {
    }

    public User(int id, String name, String email, String image, String phone, int money, String create_at, String update_at) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.img = image;
        this.phone = phone;
        this.money = money;
        this.create_at = create_at;
        this.update_at = update_at;
    }

    public User(int id, String name, String email, int money) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.money = money;
    }

    public User(int id, String name, String email, String image, String phone) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.img = image;
        this.phone = phone;
    }

    public User(int id, String name, String email, String image, String phone, int money) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.img = image;
        this.phone = phone;
        this.money = money;
    }

    public User(int id, String name, String email, String image, String phone, int money, String create_at) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.img = image;
        this.phone = phone;
        this.money = money;
        this.create_at = create_at;
    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getImage() {
        return img;
    }

    public void setImage(String image) {
        this.img = image;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public int getMoney() {
        return money;
    }

    public void setMoney(int money) {
        this.money = money;
    }


    public void setCreate_at(String create_at) {
        this.create_at = create_at;
    }

    public void setUpdate_at(String update_at) {
        this.update_at = update_at;
    }

    public String getCreate_at() {
        return create_at;
    }

    public String getUpdate_at() {
        return update_at;
    }

}
