package com.nhule.ebookapp.model;

public class ReadHistory {
    int id;
    String ebookName;

    public ReadHistory() {
    }

    public ReadHistory(int id, String ebookName) {
        this.id = id;
        this.ebookName = ebookName;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEbookName() {
        return ebookName;
    }

    public void setEbookName(String ebookName) {
        this.ebookName  = ebookName;
    }
}
