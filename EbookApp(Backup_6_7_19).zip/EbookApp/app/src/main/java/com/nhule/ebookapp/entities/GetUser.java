package com.nhule.ebookapp.entities;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.nhule.ebookapp.model.User;

public class GetUser {
    @SerializedName("message")
    @Expose
    String message;
    @SerializedName("user")
    @Expose
    User user;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
